@extends('layout')
  
@section('content')
<div class="row">
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <div class="card-title align-items-start flex-column">
               <h3>{{__('Project List')}}</h3>
            </div>
            <div class="card-toolbar">
                <div class="d-flex justify-content-end" data-kt-subscription-table-toolbar="base">
                    <div class="row me-3 bg-light p-2">
        
                    </div>
                  
                    <a href="{{ route('projects.create')}}" class="btn btn-md btn-primary">{{__('Add Project')}}</a>
                  
                   
                </div>
               
            </div>
        </div>
        <div class="card-body table-responsive">
            <table id="projecttable" class="table table-hover project_datatable" aria-label="">
                <thead class="fw-bolder text-muted bg-light">
                  <tr class="table-heading-row">
                    <th>{{__('#')}}</th>
                    <th>{{__('Project code')}}</th>
                    <th>{{__('Project Name')}}</th>
                    <th>{{__('Action')}}</th>
                  </tr>
                </thead>
               
                <tbody>
                @foreach($projects as $project)
                    <tr class="table-heading-row">
                        <td>{{__('#')}}</td>
                        <td>PT0{{$project->id}}</td>
                        <td><b>{{$project->title}}</b><br/><br/>
                            @foreach($project->tasks as $task)
                            {{$task->task_title}}<br/>
                            @endforeach
                        </td>
                        <td><a class="d-inline me-3" href="{{ route('projects.edit', $project->id) }}" data-bs-toggle="tooltip" data-bs-placement="top" title="{{__('Edit')}}">
        <i class="bi bi-pencil fs-3 text-primary"></i>Edit
      </a>/<a class="d-inline me-3" href="{{ route('projects.delete', $project->id) }}" data-bs-toggle="tooltip" data-bs-placement="top" title="{{__('Delete')}}">
        <i class="bi bi-pencil fs-3 text-primary"></i>Delete
      </a></td>
                    </tr>
                @endforeach
                </tbody>
                
            </table>
        </div>
        
    </div>
</div>
</div>
       
@endsection
