@extends('layout')
  
@section('content')
<div class="row">
    <div class="col-md-12">
    <div class="card">
        <form action="{{ route('projects.update', $project->id) }}" method="POST" id="project">
            @csrf
            @method('PUT')
            <div class="card-body d-flex flex-column flex-lg-row bg-light">
                <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10 w-100 mb-5 me-lg-10">

                <div class="card card-flush py-4">

                <div class="card-body pt-0">
                    <div class="form-group fv-row mb-5 fv-plugins-icon-container">
                        <label for="title" class="d-flex required align-items-center fs-6 fw-bold mb-2">Project</label>
                        <input name="title" type="text" class="form-control @error('title') is-invalid @enderror mb-3 mb-lg-0" id="title" placeholder="Enter Project Title" value="{{ $project->title }}" required autofocus>
                        @error('title')
                        <span class="fv-plugins-message-container invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                    <div class="form-group fv-row mb-5 fv-plugins-icon-container">
                        <label for="title" class="d-flex required align-items-center fs-6 fw-bold mb-2">Tasks</label>
                        <textarea name="tasks" class="form-control @error('tasks') is-invalid @enderror mb-3 mb-lg-0" rows="5" required placeholder="Enter Project Tasks">  @foreach($project->tasks as $task)
{{ $task->task_title }}
@endforeach</textarea>
                        @error('tasks')
                        <span class="fv-plugins-message-container invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                </div>

                </div>

                </div>
                </div>
            </div>
            <div class="card-footer">
                <a href="{{route('projects.index')}}"><button type="button" class="btn btn-danger">{{__('Cancel')}}</button></a>
                <button type="submit" class="btn btn-primary"> {{__('Update')}}</button>
            </div>
        </form>
    </div>
</div>
</div>

@endsection
