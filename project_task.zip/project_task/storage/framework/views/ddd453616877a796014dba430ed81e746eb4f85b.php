
  
<?php $__env->startSection('content'); ?>
      <div class="container"><br/><br/>
      <a class="btn btn-sm btn-danger" href="<?php echo e(route('view-plans')); ?>" style="float:right">View Plans</a>
      <span style="text-align:center;color:green"><h2>User Subscriptions</h2></span>

        <table class="table table-bordered payment_datatable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Plan Name</th>
                    <th>Amount</th>
                    <th>Record Type</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Payment/Request Date</th>
                    <th>Last Activity Date</th>
                    <th>Status</th>
                    <th>Payment Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $userSubscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userSubscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($userSubscription->id); ?></td>
                        <td><?php echo e($userSubscription->plan_name); ?></td>
                        <td><i class="fa fa-rupee"></i><?php echo e($userSubscription->price); ?></td>
                        <td><button class="btn btn-sm btn-secondary"><?php echo e(ucwords($userSubscription->entry_type)); ?></button></td>
                        <td><?php echo e($userSubscription->start_date); ?></td>
                        <td><?php echo e($userSubscription->end_date); ?></td>
                        <td><?php echo e($userSubscription->created_at); ?></td>
                        <td><?php echo e($userSubscription->updated_at); ?></td>
                        <td><button class="btn btn-sm btn-<?php echo e($userSubscription->status == 'Active' ? 'success' : 'danger'); ?>"><?php echo e($userSubscription->status); ?></button></td>
                        <td><button class="btn btn-sm btn-info"><?php echo e(ucwords($userSubscription->payment_status)); ?></button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<script>
    let table = new DataTable('.payment_datatable');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.2\htdocs\laravel-stripe\resources\views/subscription/history.blade.php ENDPATH**/ ?>