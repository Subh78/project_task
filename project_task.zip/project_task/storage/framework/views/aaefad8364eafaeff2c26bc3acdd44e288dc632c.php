
  
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
    <div class="card">
        <form action="<?php echo e(route('projects.update', $project->id)); ?>" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate id="project">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card-body d-flex flex-column flex-lg-row bg-light">
                <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10 w-100 mb-5 me-lg-10">

                <div class="card card-flush py-4">

                <div class="card-body pt-0">
                    <div class="form-group fv-row mb-5 fv-plugins-icon-container">
                        <label for="title" class="d-flex required align-items-center fs-6 fw-bold mb-2">Project</label>
                        <input name="title" type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> mb-3 mb-lg-0" id="title" placeholder="Enter Project Title" value="<?php echo e($project->title); ?>" required autofocus>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="fv-plugins-message-container invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group fv-row mb-5 fv-plugins-icon-container">
                        <label for="title" class="d-flex required align-items-center fs-6 fw-bold mb-2">Tasks</label>
                        <textarea name="tasks" class="form-control <?php $__errorArgs = ['tasks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> mb-3 mb-lg-0" rows="5" required placeholder="Enter Project Tasks"> <?php $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($task->task_title); ?><br/>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></textarea>
                        <?php $__errorArgs = ['tasks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="fv-plugins-message-container invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                </div>

                </div>
                </div>
            </div>
            <div class="card-footer">
                <a href="<?php echo e(route('projects.index')); ?>"><button type="button" class="btn btn-danger"><?php echo e(__('Cancel')); ?></button></a>
                <button type="submit" class="btn btn-primary"> <?php echo e(__('Update')); ?></button>
            </div>
        </form>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.2\htdocs\project_task\resources\views/project/edit.blade.php ENDPATH**/ ?>