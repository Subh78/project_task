
  
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            </div>
            <div class="col-md-6">
                <form id="payment-form">
                    <div id="payment-element" style="margin:auto">
                        <!-- Elements will create form elements here -->
                    </div><br/>
                    <button class="btn btn-md btn-info" style="text-align:center" id="submit">Submit</button>
                    <div id="error-message">
                        <!-- Display error message to your customers here -->
                    </div>
                </form>
            </div>
        </div>
    </div>




<script>
    $(document).ready(function() {
        var stripe = Stripe('<?php echo e(env('STRIPE_KEY')); ?>');
        console.log(stripe);
        const options = {
        clientSecret: '<?php echo e($token); ?>',
        // Fully customizable with appearance API.
        appearance: {/*...*/},
        };

        // Set up Stripe.js and Elements to use in checkout form, passing the client secret obtained in a previous step
        const elements = stripe.elements(options);

        // Create and mount the Payment Element
        const paymentElement = elements.create('payment');
        paymentElement.mount('#payment-element');

        const form = document.getElementById('payment-form');

        form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const {error} = await stripe.confirmPayment({
            //`Elements` instance that was used to create the Payment Element
            elements,
            confirmParams: {
            return_url: '<?php echo e(env('YOUR_DOMAIN') . '/complete?plan_id='.$plan_id); ?>',
            },
        });

        if (error) {
            // This point will only be reached if there is an immediate error when
            // confirming the payment. Show error to your customer (for example, payment
            // details incomplete)
            const messageContainer = document.querySelector('#error-message');
            messageContainer.textContent = error.message;
        } else {
            // Your customer will be redirected to your `return_url`. For some payment
            // methods like iDEAL, your customer will be redirected to an intermediate
            // site first to authorize the payment, then redirected to the `return_url`.
        }
        });
    });
    
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.2\htdocs\laravel-stripe\resources\views/plans/cardelement.blade.php ENDPATH**/ ?>