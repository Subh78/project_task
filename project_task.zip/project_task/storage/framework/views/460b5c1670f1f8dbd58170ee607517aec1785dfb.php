
  
<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <div class="card-title align-items-start flex-column">
               <h3><?php echo e(__('Project List')); ?></h3>
            </div>
            <div class="card-toolbar">
                <div class="d-flex justify-content-end" data-kt-subscription-table-toolbar="base">
                    <div class="row me-3 bg-light p-2">
        
                    </div>
                  
                    <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-md btn-primary"><?php echo e(__('Add Project')); ?></a>
                  
                   
                </div>
               
            </div>
        </div>
        <div class="card-body table-responsive">
            <table id="projecttable" class="table table-hover project_datatable" aria-label="">
                <thead class="fw-bolder text-muted bg-light">
                  <tr class="table-heading-row">
                    <th><?php echo e(__('#')); ?></th>
                    <th><?php echo e(__('Project code')); ?></th>
                    <th><?php echo e(__('Project Name')); ?></th>
                    <th><?php echo e(__('Action')); ?></th>
                  </tr>
                </thead>
               
                <tbody>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table-heading-row">
                        <td><?php echo e(__('#')); ?></td>
                        <td>PT0<?php echo e($project->id); ?></td>
                        <td><b><?php echo e($project->title); ?></b><br/><br/>
                            <?php $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($task->task_title); ?><br/>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><a class="d-inline me-3" href="<?php echo e(route('projects.edit', $project->id)); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(__('Edit')); ?>">
        <i class="bi bi-pencil fs-3 text-primary"></i>Edit
      </a>/<a class="d-inline me-3" href="<?php echo e(route('projects.delete', $project->id)); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(__('Delete')); ?>">
        <i class="bi bi-pencil fs-3 text-primary"></i>Delete
      </a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
            </table>
        </div>
        
    </div>
</div>
</div>
       
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.2\htdocs\project_task\resources\views/projects/index.blade.php ENDPATH**/ ?>