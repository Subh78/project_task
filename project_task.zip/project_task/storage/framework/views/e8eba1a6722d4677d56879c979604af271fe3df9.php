
  
<?php $__env->startSection('content'); ?>
      <div class="container"><br/><br/>
     <p><b style="color:blue;">NOTE : ALL THE IMMEDIATE PLAN UPGRADE AND DOWNGRADE REQUEST WILL TAKE 26 - 28 Hrs. TIMELINE TO REFLECT IN YOUR ACCOUNT </b></p>
        <a class="btn btn-sm btn-danger" href="<?php echo e(route('payment-history')); ?>" style="float:right">Subscription History</a>
        <br/><br/>
        <?php if(isset($lastUserSubscription) && $lastUserSubscription->status == "Active"): ?>
            <div class="row">
                <div class="col-md-12">
                    <a href="<?php echo e(route('cancel-recurring')); ?>" style="float:right"><button type="button" class="btn btn-sm btn-warning clearfix"><i class="fa fa-close"></i>&nbsp;Cancel Recurring</button></a>
                    <br/><br/><small style="float:right;color:green">By cancelling it, All your recurring payment and previous plan switch requests will be cancelled</small>
                </div>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row" style="margin:auto">
            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-3">
                    <div class="pricing pricing-warning">
                        <div class="title"><a href="/shop"><?php echo e($plan->plan_name); ?></a></div>
                        <div class="price-box">
                            <div class="starting">Starting at</div>
                            <div class="price"><i class="fa fa-rupee"></i><?php echo e($plan->price); ?><span>/<?php echo e($plan->plan_type); ?></span></div>
                        </div>
                        <ul class="options">
                            <li class="active"><span><i class="fa fa-check"></i></span><?php echo e($plan->plan_description); ?>

                            </li>
                        </ul>
                        <div class="bottom-box">
                              <form action="<?php echo e(route('make-payment')); ?>" method="POST">
                                <?php echo csrf_field(); ?> 
                                <input type="hidden" name="plan_id" value="<?php echo e($plan->id); ?>">
                                <input type="hidden" name="plan_name" value="<?php echo e($plan->plan_name); ?>">
                                <input type="hidden" name="plan_description" value="<?php echo e($plan->plan_description); ?>">
                                <input type="hidden" name="price" value="<?php echo e($plan->price); ?>">
                                <input type="hidden" name="plan_type" value="<?php echo e($plan->plan_type); ?>">
                                <span id="buyplan<?php echo e($plan->id); ?>">
                                    <?php if($lastUserSubscription): ?>
                                        <?php if($lastUserSubscription->plan_id == $plan->id): ?>
                                            <button type="button" class="btn btn-md btn-success clearfix"><i class="fa fa-check"></i>&nbsp;Active Plan</button>
                                            
                                        <?php else: ?>
                                            <?php if(isset($lastUserRequest) && $lastUserRequest->plan_id == $plan->id): ?>
                                                <button type="button" class="btn btn-md btn-warning clearfix">Switch Requested</button>
                                                <label type="button" class="cancel-request" plan-id="<?php echo e($plan->id); ?>" style="color:red"><i class="fa fa-trash" title="cancel request"></i></label>
                                            <?php else: ?>
                                                <button type="button" class="btn btn-md btn-info clearfix switch-plan" plan-id="<?php echo e($plan->id); ?>" plan-type="<?php echo e($plan->plan_type); ?>" plan-name="<?php echo e($plan->plan_name); ?>" plan-description="<?php echo e($plan->plan_description); ?>"  plan-price="<?php echo e($plan->price); ?>" plan-enddate="<?php echo e($lastUserSubscription->end_date); ?>">Switch Plan</button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                </span>
                                <button type="submit" class="btn btn-lg btn-warning clearfix">Buy Now</button>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Add this to your HTML body -->
<div class="modal fade" id="switchPlanModal" tabindex="-1" role="dialog" aria-labelledby="switchPlanModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="switchPlanModalLabel">Switch Plan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <label>Are you sure you want to switch your current plan?</label> <br/>
                <?php if($lastUserRequest): ?>
                 <span class="label label-danger" style="color:red">All your Previous Switch requests will be cancelled by doing this activity</span> 
                <?php endif; ?>  
                <form action="<?php echo e(route('switch-plan')); ?>" method="POST">
                    <?php echo csrf_field(); ?> 
                    <input type="hidden" name="plan_id" id="switch_plan_id" value="">
                    <input type="hidden" name="plan_name" id="switch_plan_name" value="">
                    <input type="hidden" name="plan_description" id="switch_plan_description" value="">
                    <input type="hidden" name="price" id="switch_plan_price" value="">
                    <input type="hidden" name="plan_type" id="switch_plan_type" value="">
                    <input type="hidden" name="current_end_date" id="current_end_date" value="">
         
            </div>
            <div class="modal-footer">
                    <button type="submit" class="btn btn-success" name="submitButton" value="switch_now" id="confirmNow">Switch Now</button>
                    <button type="submit" class="btn btn-secondary" name="submitButton" value="switch_later"  id="confirmNext">Switch From Next Cycle</button>
                </form> 
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="cancelRequestModal" tabindex="-1" role="dialog" aria-labelledby="cancelRequestLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cancelRequestLabel">Cancel Request</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <label>Are you sure you want to cancel your switch request?</label> <br/> 
                <form action="<?php echo e(route('cancel-request')); ?>" method="POST">
                    <?php echo csrf_field(); ?> 
                    <input type="hidden" name="cancel_plan_id" id="cancel_plan_id" value="">
            </div>
            <div class="modal-footer">
                    <button type="submit" class="btn btn-danger" id="cancelNow">Cancel</button>
                </form> 
            </div>
        </div>
    </div>
</div>




<script>
    $(document).ready(function() {
        $('.switch-plan').click(function() {
            var switch_plan_id = $(this).attr("plan-id");
            var switch_plan_name = $(this).attr("plan-name");
            var switch_plan_description = $(this).attr("plan-description");
            var switch_plan_price = $(this).attr("plan-price");
            var switch_plan_type = $(this).attr("plan-type");
            var current_end_date = $(this).attr("plan-enddate");
            $('#switchPlanModal').modal('show');
            $('#switch_plan_id').val(switch_plan_id);
            $('#switch_plan_name').val(switch_plan_name);
            $('#switch_plan_description').val(switch_plan_description);
            $('#switch_plan_price').val(switch_plan_price);
            $('#switch_plan_type').val(switch_plan_type);
            $('#current_end_date').val(current_end_date);
            $('#switchPlanModal').modal('hide');
        });
        $('.cancel-request').click(function() {
            var cancel_plan_id = $(this).attr("plan-id");
            $('#cancelRequestModal').modal('show');
            $('#cancel_plan_id').val(cancel_plan_id);
            $('#cancelRequestModal').modal('hide');
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.2\htdocs\laravel-stripe\resources\views/plans/view.blade.php ENDPATH**/ ?>