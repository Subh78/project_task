<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Project;
use App\Models\Task;


class ProjectTaskController extends Controller
{
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\Http\Response
         */
        public function index(Request $request)
        {
            $projects = Project::with('tasks')->orderBy('id','desc')->get();

            return view('projects.index',compact('projects'));
        }
    
        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\Http\Response
         */
        public function create()
        {
           return view('projects.create');
        }
    
        /**
         * Store a newly created resource in storage.
         *
         * @param  \Illuminate\Http\Request  $request
         * @return \Illuminate\Http\Response
         */
        public function store(Request $request)
        {
           DB::beginTransaction();
           try{
                $project = Project::create([
                    'title' => $request->title,
                ]);
                DB::commit();
        
                $tasks = explode(PHP_EOL, $request->input('tasks'));
        
                foreach ($tasks as $task) {
        
                    $task = Task::create([
                        'task_title' => trim($task),
                        'duration' => 0,
                        'project_id' => $project->id,
                    ]);
                    DB::commit();
                }
    
            
    
                // toastr()->success(__('custom_validation.record_create', ['attribute' => 'Project']));
           }catch(\Exception $e){
            dd($e->getMessage());
                DB::rollback();
               // toastr()->error($e->getMessage());
           }
           return redirect()->route('projects.index');
        }
    
        /**
         * Show the form for editing the specified resource.
         *
         * @param  \App\Models\Project  $project
         * @return \Illuminate\Http\Response
         */
        public function edit(Project $project)
        {
            return view('projects.edit', compact('project'));
        }
    
        /**
         * Update the specified resource in storage.
         *
         * @param  \Illuminate\Http\Request  $request
         * @param  \App\Models\Project  $project
         * @return \Illuminate\Http\Response
         */
        public function update(Request $request, Project $project)
        {
            DB::beginTransaction();
           try{
                $project->update([
                    'title' => $request->title,
                ]);
    
                DB::commit();
                Task::where('project_id', $project->id)->delete();
                $tasks = explode(PHP_EOL, $request->input('tasks'));
                foreach ($tasks as $task) {
        
                    $task = Task::create([
                        'task_title' => trim($task),
                        'duration' => 0,
                        'project_id' => $project->id,
                    ]);
                    DB::commit();
                }
    
                //toastr()->success(__('custom_validation.record_update', ['attribute' => 'Project']));
    
           }catch(\Exception $e){
                DB::rollback();
                toastr()->error($e->getMessage());
           }
           return redirect()->route('projects.index');
        }
    
        /**
         * Remove the specified resource from storage.
         *
         * @param  \App\Models\Project  $project
         * @return \Illuminate\Http\Response
         */
        public function destroy(Project $project)
        {
            if(isset($project) && !empty($project)){
                DB::beginTransaction();
                try{
    
                    $project->delete();
    
                    DB::commit();
                   
    
                }catch(\Exception $e){
                    DB::rollback();
                    //toastr()->error($e->getMessage());
               }
            }else{
                DB::rollback();
                //toastr()->error(__('404 | custom_validation.data_not_found', ['attribute' => 'Project']));
            }
            return back();
        }
}
