<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
/* Stripe */
use Stripe\Stripe;
use Stripe\Customer;
/* end Stripe */

class RegistrationController extends Controller
{

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function registration()
    {
        return view('auth.registration');
    }

    public function postRegistration(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
        ]);

        /* Stripe */

        Stripe::setApiKey(env('STRIPE_SECRET'));
        $customer = Customer::create([
            'name' => $request->name,
            'email' => $request->email,
        ]);

        $request['stripe_customer_id'] = $customer->id;

        /* End Stripe */

        $data = $request->all();
        $check = $this->create($data);



        return redirect("dashboard")->withSuccess('Great! You have Successfully loggedin');
    }

    /**
     * creates the user with stripe user id in database
     *
     * @return response()
     */
    public function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'stripe_customer_id' => $data['stripe_customer_id']
        ]);
    }

}
